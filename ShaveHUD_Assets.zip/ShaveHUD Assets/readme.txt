- Akimbo Animation Tweaks (by Zdann)
units\menu\pd2_dlc_osa\*
- Hidden Content Updates (by Zdann)
units\menu\*